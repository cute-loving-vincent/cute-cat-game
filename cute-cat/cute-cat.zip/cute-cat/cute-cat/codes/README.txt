this codes were written by kiamehr the terrible, thank you for playing the game
Cute Cate- sailor moon game